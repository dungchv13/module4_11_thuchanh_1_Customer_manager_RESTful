create
    definer = root@localhost procedure delete_order(IN id int)
begin
    delete from orders where orderID = id ;
end;

